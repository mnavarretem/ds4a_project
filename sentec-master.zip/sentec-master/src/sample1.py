import es_nlp as lang_tools

print("Ingresa una frase para el proceso de NLP:")
t=input();
print(lang_tools.tokenize(t));